-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2025 at 06:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `java_user_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

CREATE TABLE `admin_details` (
  `Admin_ID` varchar(50) NOT NULL,
  `Name` varchar(55) NOT NULL,
  `Gender` varchar(8) NOT NULL,
  `Age` int(2) NOT NULL,
  `Email` varchar(35) NOT NULL,
  `Phone_Number` int(10) NOT NULL,
  `Address` varchar(80) NOT NULL,
  `SLIIT_ID` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_details`
--

INSERT INTO `admin_details` (`Admin_ID`, `Name`, `Gender`, `Age`, `Email`, `Phone_Number`, `Address`, `SLIIT_ID`) VALUES
('PAT_00037', 'r', 'Other', 45, 'fcddfdfdf@gmail.com', 123456789, 'd,d', 'dsdd');

--
-- Triggers `admin_details`
--
DELIMITER $$
CREATE TRIGGER `getAdminID` BEFORE INSERT ON `admin_details` FOR EACH ROW BEGIN
 INSERT patient_counter VALUES(NULL);
  SET NEW.Admin_ID = concat("PAT_", 
       LPAD(LAST_INSERT_ID(),5,"0"));
  END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `book_appoin`
--

CREATE TABLE `book_appoin` (
  `Appoint_ID` varchar(55) NOT NULL,
  `Doc_ID` varchar(55) NOT NULL,
  `P_Name` varchar(55) NOT NULL,
  `P_Email` varchar(55) NOT NULL,
  `P_Date` date NOT NULL,
  `P_Time` varchar(55) NOT NULL,
  `Doc_email` varchar(55) NOT NULL,
  `Payment` enum('1000','2000','3000','4000') NOT NULL DEFAULT '1000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_appoin`
--

INSERT INTO `book_appoin` (`Appoint_ID`, `Doc_ID`, `P_Name`, `P_Email`, `P_Date`, `P_Time`, `Doc_email`, `Payment`) VALUES
('BK_00111', 'PAT_00100', 'venuve', 'venuthiru185@gmail.com', '2025-02-10', '8.00', 'Doctor5@gmail.com', '1000'),
('INV_00095', 'f', 'f', 'f', '0000-00-00', 'f', 'f', '1000');

--
-- Triggers `book_appoin`
--
DELIMITER $$
CREATE TRIGGER `getappID` BEFORE INSERT ON `book_appoin` FOR EACH ROW BEGIN
 INSERT patient_counter VALUES(NULL);
  SET NEW.Appoint_ID = concat("BK_", 
       LPAD(LAST_INSERT_ID(),5,"0"));
  END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `doctor_details`
--

CREATE TABLE `doctor_details` (
  `Doctor_ID` varchar(50) NOT NULL,
  `Name` varchar(55) NOT NULL,
  `Gender` varchar(8) NOT NULL,
  `Age` int(2) NOT NULL,
  `Email` varchar(35) NOT NULL,
  `Phone_Number` varchar(10) NOT NULL,
  `Address` varchar(80) NOT NULL,
  `Specilation` varchar(55) NOT NULL,
  `SLMC_ID` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_details`
--

INSERT INTO `doctor_details` (`Doctor_ID`, `Name`, `Gender`, `Age`, `Email`, `Phone_Number`, `Address`, `Specilation`, `SLMC_ID`) VALUES
('PAT_00096', 'Doctor1', 'Male', 54, 'Doctor@gmail.com', '7854213698', 'Jaffna,144 Main Street', 'General', '0125849848984894'),
('PAT_00097', 'Doctor2', 'Male', 24, 'Doctor1@gmail.com', '5841235985', 'Jaffna,Annapanthi road', 'Neurosurgeon', '012545248984894'),
('PAT_00098', 'Doctor3', 'Female', 27, 'Doctor3@gmail.com', '5841235975', 'kopay,Chavakacheri west', 'Orthopedic', '45448984894'),
('PAT_00099', 'Doctor4', 'Female', 27, 'Doctor4@gmail.com', '5841235975', 'vadamarachi,westline ', 'Cardiothoracic', '8484989498484'),
('PAT_00100', 'Doctor5', 'Other', 78, 'Doctor5@gmail.com', '7841258741', 'Chandilipai,192 Main Street', 'Plastic', '4574484948984'),
('PAT_00101', 'Doctor6', 'Female', 80, 'Doctor6@gmail.com', '4598521026', 'chunnakam,256 kasthirui road', 'Ophthalmic', '84486545984'),
('PAT_00102', 'Doctor7', 'Male', 45, 'Doctor7@gmail.com', '4589657458', 'vadamarachi,450 sivan kovil road', 'Pediatric', '5849848949'),
('PAT_00120', 'ggdfdffg', 'Male', 45, 'dsffsg@gmail.com', '0123456897', 'fg gfg g,dsd rfgg g', 'General', '12345680');

--
-- Triggers `doctor_details`
--
DELIMITER $$
CREATE TRIGGER `getDoctorID` BEFORE INSERT ON `doctor_details` FOR EACH ROW BEGIN
 INSERT patient_counter VALUES(NULL);
  SET NEW.Doctor_ID = concat("PAT_", 
       LPAD(LAST_INSERT_ID(),5,"0"));
  END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_details`
--

CREATE TABLE `inventory_details` (
  `Inventory_ID` varchar(55) NOT NULL,
  `Inventory_Name` varchar(55) NOT NULL,
  `In_Quantity` varchar(55) NOT NULL,
  `Manufacturer` varchar(55) NOT NULL,
  `Inve_Price` varchar(55) NOT NULL,
  `Expiry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_details`
--

INSERT INTO `inventory_details` (`Inventory_ID`, `Inventory_Name`, `In_Quantity`, `Manufacturer`, `Inve_Price`, `Expiry_date`) VALUES
('cc', 'cc', 'cc', 'cc', 'cc', '2025-02-11'),
('dsd', 'dsd', 'ds', 'dsd', 'ds', '2025-02-19'),
('tryyt', 'yty', '56', 'yty', '2560.00', '2025-02-05');

-- --------------------------------------------------------

--
-- Table structure for table `patient_counter`
--

CREATE TABLE `patient_counter` (
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_counter`
--

INSERT INTO `patient_counter` (`ID`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22),
(23),
(24),
(25),
(26),
(27),
(28),
(29),
(30),
(31),
(32),
(33),
(34),
(35),
(36),
(37),
(38),
(39),
(40),
(41),
(42),
(43),
(44),
(45),
(46),
(47),
(48),
(49),
(73),
(74),
(75),
(76),
(77),
(78),
(79),
(80),
(81),
(82),
(83),
(84),
(85),
(86),
(87),
(88),
(89),
(90),
(91),
(92),
(93),
(94),
(95),
(96),
(97),
(98),
(99),
(100),
(101),
(102),
(103),
(104),
(105),
(106),
(107),
(108),
(109),
(110),
(111),
(112),
(113),
(114),
(115),
(116),
(117),
(118),
(119),
(120);

-- --------------------------------------------------------

--
-- Table structure for table `patient_details`
--

CREATE TABLE `patient_details` (
  `Patient_ID` varchar(50) NOT NULL,
  `Name` varchar(55) NOT NULL,
  `Gender` varchar(8) NOT NULL,
  `Age` int(2) NOT NULL,
  `Email` varchar(35) NOT NULL,
  `Phone_Number` varchar(15) NOT NULL,
  `Address` varchar(400) NOT NULL,
  `Insurance` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_details`
--

INSERT INTO `patient_details` (`Patient_ID`, `Name`, `Gender`, `Age`, `Email`, `Phone_Number`, `Address`, `Insurance`) VALUES
('PAT_00044', 'changeuserDetail', '', 0, 'changeuserDetail@gmail.com', '0123456789', '', ''),
('PAT_00045', 'fdsdfsfdfd', 'Other', 45, 'uddddddser@gmail.com', 'ptientseein', 'ptientseei,ptientseein', 'ptientse'),
('PAT_00046', 'fdsdfsfdfd', 'Other', 45, 'uddddxddser@gmail.com', 'ptientseein', 'ptientseei,ptientseein', 'ptientse'),
('PAT_00047', 'fdsdfsfdfd', 'Other', 45, 'uddddfxddser@gmail.com', 'ptientseein', 'ptientseei,ptientseein', 'ptientse'),
('PAT_00048', 'fdsdfsfdfd', 'Other', 45, 'uddser@gmail.com', 'ptientseein', 'ptientseei,ptientseein', 'ptientse'),
('PAT_00049', 'fdsdfsfdfd', 'Other', 45, 'cser@gmail.com', 'ptientseein', 'ptientseei,ptientseein', 'ptientse'),
('PAT_00073', 'fdsdfsfdfd', 'Other', 45, 'cccer@gmail.com', 'ptientseein', 'ptientseei,ptientseein', 'ptientse'),
('PAT_00077', 'rtrt', 'Female', 56, 'ertgrfgtrf@gmail.com', '154198', '1215849,154198', 'rrr');

--
-- Triggers `patient_details`
--
DELIMITER $$
CREATE TRIGGER `getpatientID` BEFORE INSERT ON `patient_details` FOR EACH ROW BEGIN
 INSERT patient_counter VALUES(NULL);
  SET NEW.Patient_ID = concat("PAT_", 
       LPAD(LAST_INSERT_ID(),5,"0"));
  END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist_details`
--

CREATE TABLE `pharmacist_details` (
  `pharmacist_ID` varchar(50) NOT NULL,
  `Name` varchar(55) NOT NULL,
  `Gender` varchar(8) NOT NULL,
  `Age` int(2) NOT NULL,
  `Email` varchar(35) NOT NULL,
  `Phone_Number` varchar(10) NOT NULL,
  `Address` varchar(80) NOT NULL,
  `STB_ID` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pharmacist_details`
--

INSERT INTO `pharmacist_details` (`pharmacist_ID`, `Name`, `Gender`, `Age`, `Email`, `Phone_Number`, `Address`, `STB_ID`) VALUES
('PAT_00039', 'rrrrrrrrrrrrr', 'Male', 54, 'yahooo@gmail.com', '0123456789', 'fgfgfgfg,grg', 'fgfg');

--
-- Triggers `pharmacist_details`
--
DELIMITER $$
CREATE TRIGGER `getPharmacistID` BEFORE INSERT ON `pharmacist_details` FOR EACH ROW BEGIN
 INSERT patient_counter VALUES(NULL);
  SET NEW.pharmacist_ID = concat("PAT_", 
       LPAD(LAST_INSERT_ID(),5,"0"));
  END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `revenue_all`
--

CREATE TABLE `revenue_all` (
  `Red_ID` varchar(55) NOT NULL,
  `Appointment` varchar(100) NOT NULL,
  `Inventory` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `revenue_all`
--
DELIMITER $$
CREATE TRIGGER `getrevenue` BEFORE INSERT ON `revenue_all` FOR EACH ROW BEGIN
 INSERT patient_counter VALUES(NULL);
  SET NEW.Red_ID = concat("PAT_", 
       LPAD(LAST_INSERT_ID(),5,"0"));
  END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_id` varchar(15) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `Phone_number` varchar(10) NOT NULL,
  `Occupation` enum('Patient','Doctor','Pharmacist','Admin') NOT NULL DEFAULT 'Patient'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_id`, `full_name`, `email`, `password`, `Phone_number`, `Occupation`) VALUES
('13', 'Patient', 'patient@gmail.com', '123456', '0071234568', 'Patient'),
('14', 'Doctor', 'doctor@gmail.com', '123456', '0771234567', 'Doctor'),
('15', 'Inventory', 'Inventory@gmail.com', '123456', '0778954568', 'Pharmacist'),
('16', 'Admin', 'admin@gmail.com', '123456', '0778956421', 'Admin'),
('17', 'FDF', 'FDF', 'FD', 'FD', 'Doctor'),
('18', 'FDF', 'FDF', 'FD', 'FD', 'Doctor'),
('USER_00006', 'TYT', 'YTY', 'YT', 'YT', 'Doctor'),
('USER_00007', 'TYT', 'YTY', 'YT', 'YT', 'Doctor'),
('USER_00008', 'dfdf', 'admin@gmail.com', 'dsdfd', '0123456789', 'Patient'),
('USER_00041', 'edere', 'gfgfgf@gmail.com', '123456', '0123456789', 'Patient'),
('USER_00042', 'erwr', 'rwerer@gmail.com', 'rwerer@gmail.com', '0123456789', 'Patient'),
('USER_00043', 'changeuserDetail', 'changeuserDetail@gmail.com', 'changeuserDetail@gmail.com', '0123456789', 'Patient'),
('USER_00088', 'fdf', 'fdf', 'fdf', 'fdf', 'Doctor'),
('USER_00089', 'fdf', 'fdf', 'fdf', 'fdf', 'Doctor'),
('USER_00112', 'fffdfdf', 'frfdfds@gmail.com', '1234569798595', '0123456789', 'Patient');

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `getUserID` BEFORE INSERT ON `user` FOR EACH ROW BEGIN
 INSERT patient_counter VALUES(NULL);
  SET NEW.User_id = concat("USER_", 
       LPAD(LAST_INSERT_ID(),5,"0"));
  END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_details`
--
ALTER TABLE `admin_details`
  ADD PRIMARY KEY (`Admin_ID`);

--
-- Indexes for table `book_appoin`
--
ALTER TABLE `book_appoin`
  ADD PRIMARY KEY (`Appoint_ID`);

--
-- Indexes for table `doctor_details`
--
ALTER TABLE `doctor_details`
  ADD PRIMARY KEY (`Doctor_ID`);

--
-- Indexes for table `inventory_details`
--
ALTER TABLE `inventory_details`
  ADD PRIMARY KEY (`Inventory_ID`);

--
-- Indexes for table `patient_counter`
--
ALTER TABLE `patient_counter`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `patient_details`
--
ALTER TABLE `patient_details`
  ADD PRIMARY KEY (`Patient_ID`);

--
-- Indexes for table `pharmacist_details`
--
ALTER TABLE `pharmacist_details`
  ADD PRIMARY KEY (`pharmacist_ID`);

--
-- Indexes for table `revenue_all`
--
ALTER TABLE `revenue_all`
  ADD PRIMARY KEY (`Red_ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patient_counter`
--
ALTER TABLE `patient_counter`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
