/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.team3.LoginSignup;

/**
 *
 * @author Keert
 */
public class NewClass {
    
    public class Team3 {

    public static void main(String[] args) {
        
       java.awt.EventQueue.invokeLater(new Runnable() {
            
            @Override
            public void run() {
                Login1 Login1Frame = new Login1();
                Login1Frame.setVisible(true);
                Login1Frame.pack();
                Login1Frame.setLocationRelativeTo(null); //center 
             
            /*    Edit_Profiledoc Edit_ProfiledocFrame = new    Edit_Profiledoc();
               Edit_ProfiledocFrame.setVisible(true);
                Edit_ProfiledocFrame.pack();
               Edit_ProfiledocFrame.setLocationRelativeTo(null); //center */
                
                
        // TODO code application logic here
    }
       });
    }
}

    
}
